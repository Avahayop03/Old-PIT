-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2024 at 12:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs_librarymanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblogin`
--

CREATE TABLE `tblogin` (
  `Username` varchar(60) NOT NULL,
  `Password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblogin`
--

INSERT INTO `tblogin` (`Username`, `Password`) VALUES
('2r7', '2r7');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_books`
--

CREATE TABLE `tbl_books` (
  `ISBN` int(13) NOT NULL,
  `book_title` varchar(70) NOT NULL,
  `author` text NOT NULL,
  `category` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_books`
--

INSERT INTO `tbl_books` (`ISBN`, `book_title`, `author`, `category`) VALUES
(1, 'heartstopper', 'avah', 'bl'),
(2, 'rewinds', 'idk', 'slice of life'),
(3, 'good girl ', 'kath', 'thrill'),
(4, 'slayskie', 'by avahskie', 'women'),
(13, 'a very good girl', 'intense', 'thriller'),
(123, 'greed', 'ariana', '18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_issue_book`
--

CREATE TABLE `tbl_issue_book` (
  `issue_book_id` int(10) NOT NULL,
  `ISBN` int(11) NOT NULL,
  `book_title` varchar(70) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_name` text NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_issue_book`
--

INSERT INTO `tbl_issue_book` (`issue_book_id`, `ISBN`, `book_title`, `student_id`, `student_name`, `issue_date`, `due_date`, `status`) VALUES
(38, 1, 'heartstopper', 3, 'ayop', '2024-01-02', '2024-01-05', 'returned'),
(39, 1, 'heartstopper', 8, 'avah', '2024-01-02', '2024-01-12', 'returned'),
(40, 1, 'heartstopper', 5, 'ayop', '2024-01-04', '2024-01-19', 'pending'),
(41, 2, 'rewinds', 6, 'nino', '2024-01-03', '2024-01-12', 'returned'),
(42, 1, 'heartstopper', 8, 'avah', '2024-01-02', '2024-01-12', 'pending'),
(43, 4, 'slayskie', 3, 'denesse', '2024-01-04', '2024-01-09', 'returned');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studentlists`
--

CREATE TABLE `tbl_studentlists` (
  `student_id` int(11) NOT NULL,
  `student_name` text NOT NULL,
  `college` text NOT NULL,
  `major_dept` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_studentlists`
--

INSERT INTO `tbl_studentlists` (`student_id`, `student_name`, `college`, `major_dept`) VALUES
(1, 'avah', 'CITC', 'BSIT'),
(3, 'denesse', 'CITC', 'BSIT'),
(5, 'ayop', 'CITC', 'BSIT'),
(6, 'nino', 'CITC', 'BSIT'),
(12, 'S', 'CITC', 'BSIT'),
(13, 'markrey', 'CEA', 'BSDS');

-- --------------------------------------------------------

--
-- Table structure for table `tbsignupstudent`
--

CREATE TABLE `tbsignupstudent` (
  `SignUp_ID` int(11) NOT NULL,
  `First Name` text NOT NULL,
  `Last Name` text NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Create Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbsignupstudent`
--

INSERT INTO `tbsignupstudent` (`SignUp_ID`, `First Name`, `Last Name`, `Email`, `Create Password`) VALUES
(14, 'lol', 'lol', 'lol', 'lol'),
(16, 'a', 'a', 'asd', 'asd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblogin`
--
ALTER TABLE `tblogin`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `tbl_books`
--
ALTER TABLE `tbl_books`
  ADD PRIMARY KEY (`ISBN`);

--
-- Indexes for table `tbl_issue_book`
--
ALTER TABLE `tbl_issue_book`
  ADD PRIMARY KEY (`issue_book_id`);

--
-- Indexes for table `tbl_studentlists`
--
ALTER TABLE `tbl_studentlists`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `tbsignupstudent`
--
ALTER TABLE `tbsignupstudent`
  ADD PRIMARY KEY (`SignUp_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_issue_book`
--
ALTER TABLE `tbl_issue_book`
  MODIFY `issue_book_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_studentlists`
--
ALTER TABLE `tbl_studentlists`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbsignupstudent`
--
ALTER TABLE `tbsignupstudent`
  MODIFY `SignUp_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
