package librarymanagementsystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class ReturnBook extends JFrame {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField issueID;
	private JTextField bookTitle;
	private JTextField studName;
	private JTextField isbn;
	private JTextField studentID;
	private JTextField issuedDate;
	private JTextField dueDate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReturnBook frame = new ReturnBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReturnBook() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ReturnBook.class.getResource("/Images/USTP_icon.png")));
		setTitle("Return Book");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 688, 457);
		contentPane = new JPanel();
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel1 = new JPanel();
		panel1.setLayout(null);
		panel1.setBackground(new Color(32, 27, 80));
		panel1.setBounds(0, 0, 245, 423);
		contentPane.add(panel1);

		JLabel lblIssueId = new JLabel("Issue ID:");
		lblIssueId.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblIssueId.setForeground(new Color(248, 178, 38));
		lblIssueId.setBounds(22, 84, 99, 51);
		panel1.add(lblIssueId);

		issueID = new JTextField();
		issueID.setColumns(10);
		issueID.setBounds(22, 123, 197, 25);
		panel1.add(issueID);

		JLabel lblBookTitle = new JLabel("Book Title:");
		lblBookTitle.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblBookTitle.setForeground(new Color(248, 178, 38));
		lblBookTitle.setBounds(22, 146, 99, 51);
		panel1.add(lblBookTitle);

		bookTitle = new JTextField();
		bookTitle.setColumns(10);
		bookTitle.setBounds(22, 189, 197, 25);
		panel1.add(bookTitle);

		JLabel lblStudentName = new JLabel("Student Name:");
		lblStudentName.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblStudentName.setForeground(new Color(248, 178, 38));
		lblStudentName.setBounds(22, 208, 99, 51);
		panel1.add(lblStudentName);

		studName = new JTextField();
		studName.setColumns(10);
		studName.setBounds(22, 254, 197, 25);
		panel1.add(studName);

		JLabel lblNewLabel_1_2_1 = new JLabel("BOOK DETAILS");
		lblNewLabel_1_2_1.setForeground(new Color(248, 178, 38));
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_1_2_1.setBounds(54, 34, 137, 51);
		panel1.add(lblNewLabel_1_2_1);

		JLabel btnBack = new JLabel("");
		btnBack.setIcon(new ImageIcon(ReturnBook.class.getResource("/Images/back (2).png")));
		btnBack.setHorizontalAlignment(SwingConstants.CENTER);
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				HomePageAdmin homePageAdmin = new HomePageAdmin();
				homePageAdmin.setVisible(true);
				dispose();

			}
		});
		btnBack.setForeground(Color.BLACK);
		btnBack.setBounds(0, 0, 50, 50);
		panel1.add(btnBack);

		issuedDate = new JTextField();
		issuedDate.setColumns(10);
		issuedDate.setBounds(22, 316, 197, 25);
		panel1.add(issuedDate);

		JLabel lblIssuedDate = new JLabel("Issued Date:");
		lblIssuedDate.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblIssuedDate.setForeground(new Color(248, 178, 38));
		lblIssuedDate.setBounds(22, 270, 99, 51);
		panel1.add(lblIssuedDate);

		dueDate = new JTextField();
		dueDate.setColumns(10);
		dueDate.setBounds(22, 378, 197, 25);
		panel1.add(dueDate);

		JLabel lblStudentName_1_1 = new JLabel("Due Date:");
		lblStudentName_1_1.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblStudentName_1_1.setForeground(new Color(248, 178, 38));
		lblStudentName_1_1.setBounds(22, 332, 99, 51);
		panel1.add(lblStudentName_1_1);

		JLabel lblRtrnBk = new JLabel("RETURN BOOK");
		lblRtrnBk.setHorizontalAlignment(SwingConstants.CENTER);
		lblRtrnBk.setForeground(new Color(32, 27, 80));
		lblRtrnBk.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblRtrnBk.setBounds(380, 33, 150, 51);
		contentPane.add(lblRtrnBk);

		JLabel lblRefresh = new JLabel("");
		lblRefresh.setHorizontalAlignment(SwingConstants.CENTER);
		lblRefresh.setIcon(new ImageIcon(ReturnBook.class.getResource("/Images/refresh.png")));
		lblRefresh.setForeground(Color.BLACK);
		lblRefresh.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblRefresh.setBounds(620, 0, 50, 50);
		contentPane.add(lblRefresh);

		JLabel lblIsbn = new JLabel("ISBN:");
		lblIsbn.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblIsbn.setForeground(new Color(32, 27, 80));
		lblIsbn.setBounds(357, 121, 99, 51);
		contentPane.add(lblIsbn);

		isbn = new JTextField();
		isbn.setColumns(10);
		isbn.setBounds(357, 160, 197, 25);
		contentPane.add(isbn);

		JLabel lblStudentId = new JLabel("Student ID:");
		lblStudentId.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblStudentId.setForeground(new Color(32, 27, 80));
		lblStudentId.setBounds(357, 183, 99, 51);
		contentPane.add(lblStudentId);

		studentID = new JTextField();
		studentID.setColumns(10);
		studentID.setBounds(357, 226, 197, 25);
		contentPane.add(studentID);

		JLabel lblFind = new JLabel("");
		lblFind.setHorizontalAlignment(SwingConstants.CENTER);
		lblFind.setIcon(new ImageIcon(ReturnBook.class.getResource("/Images/find.png")));
		lblFind.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				issueBookDetails();

			}
		});
		lblFind.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblFind.setForeground(Color.BLACK);
		lblFind.setBounds(410, 287, 90, 40);
		contentPane.add(lblFind);

		JLabel lblReturnBook = new JLabel("");
		lblReturnBook.setHorizontalAlignment(SwingConstants.CENTER);
		lblReturnBook.setIcon(new ImageIcon(ReturnBook.class.getResource("/Images/return.png")));
		lblReturnBook.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				returnBooks();
			}
		});
		lblReturnBook.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblReturnBook.setForeground(Color.BLACK);
		lblReturnBook.setBounds(410, 344, 90, 40);
		contentPane.add(lblReturnBook);
		Connect();
		
		JLabel lblBg = new JLabel("");
		lblBg.setHorizontalAlignment(SwingConstants.LEFT);
		lblBg.setIcon(new ImageIcon(ReturnBook.class.getResource("/Images/USTP_bg (5).png")));
		lblBg.setBounds(241, 0, 429, 418);
		contentPane.add(lblBg);

	}// connection area//

	public void Connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dbs_librarymanagement", "root", "");
		} catch (ClassNotFoundException | SQLException ex) {
			Logger.getLogger(ReturnBook.class.getName()).log(Level.SEVERE, null, ex);

		}
	}

	private void returnBooks() {
		String isbnBook, stdID;
		isbnBook = isbn.getText();
		stdID = studentID.getText();
		// status = btnStatus.getText();

		try {
			pst = con.prepareStatement(
					"UPDATE tbl_issue_book SET status = ? WHERE 	ISBN = ? AND student_id = ? AND status = ? ");
			pst.setString(1, "returned");

			pst.setString(2, isbnBook); // Corrected order
			pst.setString(3, stdID); // Corrected order
			pst.setString(4, "pending");

			int rowsUpdated = pst.executeUpdate();

			if (rowsUpdated > 0) {
				// The update was successful
				// You can perform any additional actions here
				JOptionPane.showMessageDialog(null, "Book status updated to 'returned'");
			} else {
				// No records were updated, meaning the condition in the WHERE clause was not
				// met
				JOptionPane.showMessageDialog(null,
						"No records updated. Maybe the book was not pending or the record does not exist.");

			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(null, ex.getMessage());
		}

	}

	// a method to find records from the issue book

	private void issueBookDetails() {
		String isbnBook, stdID;
		isbnBook = isbn.getText();
		stdID = studentID.getText();

		try {
			pst = con.prepareStatement(
					"SELECT issue_book_id, book_title, student_name, issue_date, due_date FROM tbl_issue_book WHERE ISBN = ? AND student_id = ? ");
			pst.setString(1, isbnBook);
			pst.setString(2, stdID);

			rs = pst.executeQuery();

			if (rs.next() == true) {
				String IDissue = rs.getString(1);
				String titleBook = rs.getString(2);
				String nameStud = rs.getString(3);
				String dateIssue = rs.getString(4);
				String dateDue = rs.getString(5);

				JOptionPane.showMessageDialog(null, "Record Found");
				issueID.setText(IDissue);
				bookTitle.setText(titleBook);
				studName.setText(nameStud);
				issuedDate.setText(dateIssue);
				dueDate.setText(dateDue);

				isbn.requestFocus();

			} else {
				JOptionPane.showMessageDialog(null, "Record not found");
				clearFields();

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	//

	// a method to return books

	private void clearFields() {
		issueID.setText("");
		bookTitle.setText("");
		studName.setText("");
	}
}
