package librarymanagementsystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

//import net.proteanit.sql.DbUtils;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;


public class ViewRecords extends JFrame {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private DefaultTableModel model;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	private JTable tblReturnedBooks;
	private JTable tblIssuedBooks;
	private JScrollPane scrollPane1;
	private JScrollPane scrollPane2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewRecords frame = new ViewRecords();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewRecords() {
	    Connect();
		setTitle("View Records");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblReturnBooks = new JLabel("");
		lblReturnBooks.setHorizontalAlignment(SwingConstants.CENTER);
		lblReturnBooks.setIcon(new ImageIcon(ViewRecords.class.getResource("/Images/RETURNED BOOKS.png")));
		lblReturnBooks.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblReturnBooks.setBounds(24, 61, 168, 50);
		contentPane.add(lblReturnBooks);
		
		JLabel lblIssuedBooks = new JLabel("");
		lblIssuedBooks.setHorizontalAlignment(SwingConstants.CENTER);
		lblIssuedBooks.setIcon(new ImageIcon(ViewRecords.class.getResource("/Images/ISSUED  BOOKS.png")));
		lblIssuedBooks.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblIssuedBooks.setBounds(24, 274, 168, 50);
		contentPane.add(lblIssuedBooks);
		
		scrollPane1 = new JScrollPane();
		scrollPane1.setBounds(39, 111, 550, 141);
		contentPane.add(scrollPane1);
		
		tblReturnedBooks = new JTable();
		scrollPane1.setViewportView(tblReturnedBooks);
		
		scrollPane2 = new JScrollPane();
		scrollPane2.setBounds(39, 324, 550, 146);
		contentPane.add(scrollPane2);
		
		tblIssuedBooks = new JTable();
		tblIssuedBooks.setEnabled(false);
		//tblIssuedBooks.disable(true);
		scrollPane2.setViewportView(tblIssuedBooks);
		
		JLabel lblBack = new JLabel("");
		lblBack.setIcon(new ImageIcon(ViewRecords.class.getResource("/Images/back (2).png")));
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				HomePageAdmin homePageAdmin = new HomePageAdmin();
				homePageAdmin.setVisible(true);
				dispose();
			}
		});
		lblBack.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblBack.setForeground(new Color(0, 0, 0));
		lblBack.setBounds(0, 0, 50, 50);
		contentPane.add(lblBack);
		displayIssueBooks();
		displayReturnBooks();
		
		JLabel lblBg = new JLabel("");
		lblBg.setIcon(new ImageIcon(ViewRecords.class.getResource("/Images/USTP_bg (8).png")));
		lblBg.setBounds(0, 0, 650, 550);
		contentPane.add(lblBg);
	
	}

	
	
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/dbs_librarymanagement", "root", "");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ViewRecords.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    

    private void displayReturnBooks() {
        try {
            String query = "SELECT issue_book_id, ISBN, book_title, student_id, student_name, issue_date, due_date, status FROM `tbl_issue_book`";
            model = new DefaultTableModel();
            tblReturnedBooks.setModel(model);

            // Set column headers
            model.setColumnIdentifiers(new Object[]{"Issue Book ID", "ISBN", "Book Title", "Student ID", "Student Name", "Issued Date", "Due Date", "Status"});

            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("issue_book_id"),
                    rs.getString("ISBN"),
                    rs.getString("book_title"),
                    rs.getString("student_id"),
                    rs.getString("student_name"),
                    rs.getString("issue_date"),
                    rs.getString("due_date"),
                    rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(IssueBook.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void displayIssueBooks() {
        try {
            String query = "SELECT issue_book_id, ISBN, book_title, student_id, student_name, issue_date, due_date FROM `tbl_issue_book`";
            model = new DefaultTableModel();
            tblIssuedBooks.setModel(model);

            // Set column headers
            model.setColumnIdentifiers(new Object[]{"Issue Book ID", "ISBN", "Book Title", "Student ID", "Student Name", "Issued Date", "Due Date"});

            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("issue_book_id"),
                    rs.getString("ISBN"),
                    rs.getString("book_title"),
                    rs.getString("student_id"),
                    rs.getString("student_name"),
                    rs.getString("issue_date"),
                    rs.getString("due_date"),
                    
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(IssueBook.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}