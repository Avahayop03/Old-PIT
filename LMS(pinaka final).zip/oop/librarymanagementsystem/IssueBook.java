package librarymanagementsystem;

//gi-method ra nako kay arun han-ay
//should I put quantity?
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;


import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.toedter.calendar.JDateChooser;

//import java.awt.event.KeyAdapter;
//import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class IssueBook extends JFrame {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField isbn;
	private JTextField bookTitle;
	private JTextField authorsName;
	private JTextField category;
	private JTextField studID;
	private JTextField studName;
	private JTextField college;
	private JTextField majorDepart;
	public JDateChooser dateOfIssue;
	public JDateChooser dueIssueDate;
	private JButton btnSearchBook;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IssueBook frame = new IssueBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IssueBook() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(IssueBook.class.getResource("/Images/USTP_icon.png")));
		Connect();
		setTitle("Issue Book");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 767, 462);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(255, 255, 255, 100));
		panel.setBounds(506, 53, 245, 423);
		contentPane.add(panel);

		JLabel lbl_IssueDate = new JLabel("Date of Issue:");
		lbl_IssueDate.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lbl_IssueDate.setForeground(new Color(204, 51, 51));
		lbl_IssueDate.setBounds(26, 162, 99, 51);
		panel.add(lbl_IssueDate);

		// Replace the JLabel with a JButton
		JButton btnIssueBook = new JButton("");
		btnIssueBook.setIcon(new ImageIcon(IssueBook.class.getResource("/Images/issue book.png")));
		btnIssueBook.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				issueBooks();
				// date of issue
			}
		});
		btnIssueBook.setBounds(80, 314, 90, 40); // Adjust the bounds as needed
		panel.add(btnIssueBook);

		JLabel lbl_IssueBk = new JLabel("ISSUE BOOK");
		lbl_IssueBk.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_IssueBk.setForeground(new Color(204, 51, 51));
		lbl_IssueBk.setFont(new Font("Tahoma", Font.BOLD, 17));
		lbl_IssueBk.setBounds(56, 5, 137, 51);
		panel.add(lbl_IssueBk);

		dateOfIssue = new JDateChooser();
		dateOfIssue.setBounds(26, 208, 200, 25);
		panel.add(dateOfIssue);

		dueIssueDate = new JDateChooser();
		dueIssueDate.setBounds(26, 267, 200, 25);
		panel.add(dueIssueDate);

		JLabel lblDueIssue = new JLabel("Due Issue:");
		lblDueIssue.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblDueIssue.setForeground(new Color(204, 51, 51));
		lblDueIssue.setBounds(26, 224, 99, 51);
		panel.add(lblDueIssue);

		JPanel panel1 = new JPanel();
		panel1.setLayout(null);
		panel1.setBackground(new Color(32, 27, 80, 100));
		panel1.setBounds(0, 53, 245, 423);
		contentPane.add(panel1);

		JLabel lblISBN = new JLabel("Book ISBN:");
		lblISBN.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblISBN.setForeground(new Color(248, 178, 30));
		lblISBN.setBounds(26, 38, 99, 51);
		panel1.add(lblISBN);

		isbn = new JTextField();
		isbn.setColumns(10);
		isbn.setBounds(26, 77, 197, 25);
		panel1.add(isbn);

		JLabel lblBookTitle = new JLabel("Book Title:");
		lblBookTitle.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblBookTitle.setForeground(new Color(248, 178, 30));
		lblBookTitle.setBounds(26, 100, 99, 51);
		panel1.add(lblBookTitle);

		bookTitle = new JTextField();
		bookTitle.setColumns(10);
		bookTitle.setBounds(26, 143, 197, 25);
		panel1.add(bookTitle);

		JLabel lblAuthorNM = new JLabel("Author's Name:");
		lblAuthorNM.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblAuthorNM.setForeground(new Color(248, 178, 30));
		lblAuthorNM.setBounds(26, 162, 99, 51);
		panel1.add(lblAuthorNM);

		authorsName = new JTextField();
		authorsName.setColumns(10);
		authorsName.setBounds(26, 208, 197, 25);
		panel1.add(authorsName);

		JLabel lblCategory = new JLabel("Category:");
		lblCategory.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblCategory.setForeground(new Color(248, 178, 30));
		lblCategory.setBounds(26, 224, 99, 51);
		panel1.add(lblCategory);

		category = new JTextField();
		category.setColumns(10);
		category.setBounds(26, 267, 197, 25);
		panel1.add(category);

		JLabel lblNewLabel_1_2_1 = new JLabel("BOOK DETAILS");
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_1_2_1.setForeground(new Color(248, 178, 30));
		lblNewLabel_1_2_1.setBounds(50, 5, 137, 51);
		panel1.add(lblNewLabel_1_2_1);

		btnSearchBook = new JButton("");
		btnSearchBook.setHorizontalAlignment(SwingConstants.CENTER);
		btnSearchBook.setIcon(new ImageIcon(IssueBook.class.getResource("/Images/search (2).png")));
		btnSearchBook.setBounds(80, 314, 90, 40);
		btnSearchBook.setForeground(new Color(255, 255, 255));
		btnSearchBook.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				searchBook();
			}
		});
		btnSearchBook.setBounds(80, 314, 90, 40);
		panel1.add(btnSearchBook);
		btnSearchBook.setForeground(new Color(255, 255, 255));

		JPanel panel2 = new JPanel();
		panel2.setLayout(null);
		panel2.setBackground(new Color(248, 178, 30, 100));
		panel2.setBounds(251, 53, 245, 423);
		contentPane.add(panel2);

		JLabel lblStudID = new JLabel("Student ID:");
		lblStudID.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblStudID.setForeground(new Color(32, 27, 80));
		lblStudID.setBounds(26, 38, 99, 51);
		panel2.add(lblStudID);

		studID = new JTextField();
		studID.setColumns(10);
		studID.setBounds(26, 77, 197, 25);
		panel2.add(studID);

		JLabel lblStudNM = new JLabel("Student Name:");
		lblStudNM.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblStudNM.setForeground(new Color(32, 27, 80));
		lblStudNM.setBounds(26, 100, 144, 51);
		panel2.add(lblStudNM);

		studName = new JTextField();
		studName.setColumns(10);
		studName.setBounds(26, 143, 197, 25);
		panel2.add(studName);

		JLabel lblSelectCllge = new JLabel(" College:");
		lblSelectCllge.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblSelectCllge.setForeground(new Color(32, 27, 80));
		lblSelectCllge.setBounds(26, 162, 99, 51);
		panel2.add(lblSelectCllge);

		JLabel lblMajorDept = new JLabel("Major Department:");
		lblMajorDept.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 11));
		lblMajorDept.setForeground(new Color(32, 27, 80));
		lblMajorDept.setBounds(26, 224, 144, 51);
		panel2.add(lblMajorDept);

		JLabel lblStudDet = new JLabel("STUDENT DETAILS");
		lblStudDet.setForeground(new Color(32, 27, 80));
		lblStudDet.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblStudDet.setBounds(40, 5, 166, 51);
		panel2.add(lblStudDet);

		college = new JTextField();
		college.setColumns(10);
		college.setBounds(26, 208, 197, 25);
		panel2.add(college);

		majorDepart = new JTextField();
		majorDepart.setColumns(10);
		majorDepart.setBounds(26, 267, 197, 25);
		panel2.add(majorDepart);

		JButton btnSearchStudent = new JButton("");
		btnSearchStudent.setIcon(new ImageIcon(IssueBook.class.getResource("/Images/search (1).png")));
		btnSearchStudent.setHorizontalAlignment(SwingConstants.CENTER);
		btnSearchStudent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				searchStudent();
			}
		});
		btnSearchStudent.setBounds(80, 314, 90, 40); // Adjust the bounds as needed
		panel2.add(btnSearchStudent);

		JLabel lblISBN1 = new JLabel("");
		lblISBN1.setHorizontalAlignment(SwingConstants.CENTER);
		lblISBN1.setIcon(new ImageIcon(IssueBook.class.getResource("/Images/back (2).png")));
		lblISBN1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				HomePageAdmin homePageAdmin = new HomePageAdmin();
				homePageAdmin.setVisible(true);
				dispose();
			}
		});
		lblISBN1.setForeground(Color.BLACK);
		lblISBN1.setBounds(0, 0, 50, 50);
		contentPane.add(lblISBN1);

		JLabel lblRefresh = new JLabel("");
		lblRefresh.setIcon(new ImageIcon(IssueBook.class.getResource("/Images/refresh.png")));
		lblRefresh.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnRefresh();
			}
		});
		lblRefresh.setHorizontalAlignment(SwingConstants.CENTER);
		lblRefresh.setForeground(new Color(204, 51, 51));
		lblRefresh.setBounds(700, 0, 50, 50);
		contentPane.add(lblRefresh);

		JLabel lblBg = new JLabel("");
		lblBg.setIcon(new ImageIcon(IssueBook.class.getResource("/Images/USTP_bg (7).png")));
		lblBg.setBounds(0, 0, 750, 511);
		contentPane.add(lblBg);

	}

	// connection area//
	public void Connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dbs_librarymanagement", "root", "");
		} catch (ClassNotFoundException | SQLException ex) {
			Logger.getLogger(IssueBook.class.getName()).log(Level.SEVERE, null, ex);

		}
	}

	// method to handle "Issue Book" butt
	private void searchStudent() {
		try {
			String id = studID.getText();

			pst = con.prepareStatement(
					"SELECT student_id, student_name, college, major_dept FROM tbl_studentlists WHERE student_id = ?");
			pst.setString(1, id);

			ResultSet rs = pst.executeQuery();

			if (rs.next() == true) {
				String stdntID = rs.getString(1);
				String stdntName = rs.getString(2);
				String college2 = rs.getString(3);
				String majorDpt = rs.getString(4);

				JOptionPane.showMessageDialog(null, "Student Found");

				studID.setText(stdntID);
				studName.setText(stdntName);
				college.setText(college2);
				majorDepart.setText(majorDpt);

				studID.requestFocus();

			} else {
				JOptionPane.showMessageDialog(null, "Student ID not found");
				clearFieldsStud();

			}

		} catch (SQLException exc) {
			exc.printStackTrace();
		}
	}

	// a method to search books
	private void searchBook() {
		try {
			String id = isbn.getText();

			pst = con.prepareStatement("SELECT ISBN, book_title, author, category FROM tbl_books WHERE ISBN = ?");
			pst.setString(1, id);

			ResultSet rs = pst.executeQuery();

			if (rs.next() == true) {
				String ISBN = rs.getString(1);
				String book_title = rs.getString(2);
				String author = rs.getString(3);
				String categories = rs.getString(4);

				JOptionPane.showMessageDialog(null, "Book Found");
				isbn.setText(ISBN);
				bookTitle.setText(book_title);
				authorsName.setText(author);
				category.setText(categories);

				isbn.requestFocus();

			} else {
				JOptionPane.showMessageDialog(null, "Book ID not found");
				clearFields();

			}

		} catch (SQLException exc) {
			exc.printStackTrace();
		}

	}

	// a method to handle issue book
	private void issueBooks() {
		String bookISBN, book_Title, stdnt_ID, stdnt_Name;
		bookISBN = isbn.getText();
		book_Title = bookTitle.getText();
		stdnt_ID = studID.getText();
		stdnt_Name = studName.getText();

		if (bookISBN.isEmpty() || stdnt_ID.isEmpty()) {
			// Show a message dialog indicating that both student and book details should be
			// selected
			JOptionPane.showMessageDialog(null, "Please choose both student and book details before issuing the book.",
					"Error", JOptionPane.ERROR_MESSAGE);
			return; // Return from the method without proceeding further
		}

		java.util.Date utilDateOfIssue = dateOfIssue.getDate();
		java.util.Date utilDueIssueDate = dueIssueDate.getDate();

		if (utilDateOfIssue == null || utilDueIssueDate == null) {
			// Show a message dialog indicating that both "Date of Issue" and "Due Issue"
			// should be selected
			JOptionPane.showMessageDialog(null,
					"Please choose both 'Date of Issue' and 'Due Issue' before issuing the book.", "Error",
					JOptionPane.ERROR_MESSAGE);
			return; // Return from the method without proceeding further
		}

		java.sql.Date sqlDateOfIssue = new java.sql.Date(utilDateOfIssue.getTime());
		String issue_Date = sqlDateOfIssue.toString();

		java.sql.Date sqlDueIssueDate = new java.sql.Date(utilDueIssueDate.getTime());
		String due_Date = sqlDueIssueDate.toString();

		 try {
		        // Check if the book is already issued to someone else
		        if (isBookAlreadyIssuedToSomeoneElse(bookISBN)) {
		            JOptionPane.showMessageDialog(null, "This book is already issued to someone else.");
		            return;
		        }

			pst = con.prepareStatement(
					"INSERT INTO tbl_issue_book (ISBN, book_title, student_id, student_name, issue_date, due_date, status) VALUES (?,?,?,?,?,?,?)");

			pst.setString(1, bookISBN);
			pst.setString(2, book_Title);
			pst.setString(3, stdnt_ID);
			pst.setString(4, stdnt_Name);
			pst.setString(5, issue_Date);
			pst.setString(6, due_Date);
			pst.setString(7, "pending");

			int rowsAffected = pst.executeUpdate();

			 pst = con.prepareStatement("UPDATE tbl_books SET is_issued = TRUE WHERE ISBN = ?");
			 pst.setString(1, bookISBN);
		        pst.executeUpdate();

			if (rowsAffected > 0) {
				JOptionPane.showMessageDialog(null, "Book Issued Successfully!");
			} else {
				JOptionPane.showMessageDialog(null, "Failed to issue the book. Please check the data and try again.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		}
	
	private boolean isBookAlreadyIssuedToSomeoneElse(String bookISBN) {
	    try {
	        pst = con.prepareStatement("SELECT is_issued FROM tbl_books WHERE ISBN = ?");
	        pst.setString(1, bookISBN);

	        ResultSet rs = pst.executeQuery();

	        if (rs.next()) {
	            boolean isIssued = rs.getBoolean("is_issued");

	            // Check if the book is already issued to someone else
	            if (isIssued) {
	                pst = con.prepareStatement("SELECT * FROM tbl_issue_book WHERE ISBN = ? AND status = 'pending'");
	                pst.setString(1, bookISBN);

	                rs = pst.executeQuery();

	                // Return true if there is a pending issuance record for this book
	                return rs.next();
	            }
	        }

	        return false;

	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        return false;
	    }
	}

	// Method to clear book-related text fields
	private void clearFields() {
		isbn.setText("");
		bookTitle.setText("");
		authorsName.setText("");
		category.setText("");

	}

	private void clearFieldsStud() {
		studID.setText("");
		studName.setText("");
		college.setText("");
		majorDepart.setText("");
	}

	private void btnRefresh() {
		isbn.setText("");
		bookTitle.setText("");
		authorsName.setText("");
		category.setText("");
		studID.setText("");
		studName.setText("");
		college.setText("");
		majorDepart.setText("");

	}
}// end of brackets
