package librarymanagementsystem;

import java.awt.EventQueue;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Toolkit;

public class HomePageAdmin extends JFrame {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private DefaultTableModel model;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePageAdmin frame = new HomePageAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	Color mouseEnterColor = new Color(0, 0, 0);
	Color mouseExitColor = new Color(0, 0, 64);
	private JTable tblStudentDetails;
	private JTable tblBookDetails;

	public HomePageAdmin() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(HomePageAdmin.class.getResource("/Images/USTP_icon.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 630, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panelTop = new JPanel();
		panelTop.setBackground(new Color(255, 255, 255, 100));
		panelTop.setBounds(0, 0, 625, 70);
		contentPane.add(panelTop);
		panelTop.setLayout(null);

		JLabel lblWlcAdmin = new JLabel("Welcome, Admin");
		lblWlcAdmin.setIcon(new ImageIcon(HomePageAdmin.class.getResource("/Images/Admin.png")));
		lblWlcAdmin.setHorizontalAlignment(SwingConstants.CENTER);
		lblWlcAdmin.setForeground(new Color(32, 27, 80));
		lblWlcAdmin.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblWlcAdmin.setBounds(0, 0, 176, 64);
		panelTop.add(lblWlcAdmin);

		JPanel panelLeft = new JPanel();
		panelLeft.setBackground(new Color(0, 0, 64));
		panelLeft.setBounds(0, 70, 159, 441);
		contentPane.add(panelLeft);
		panelLeft.setLayout(null);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 81, 139, 2);
		separator.setForeground(new Color(255, 255, 255));
		panelLeft.add(separator);

		JPanel panelDashboard = new JPanel();
		panelDashboard.setBackground(new Color(248, 178, 30));
		panelDashboard.setBounds(0, 28, 159, 42);
		panelLeft.add(panelDashboard);
		panelDashboard.setLayout(null);

		JLabel lblDashboard = new JLabel("Dashboard");
		lblDashboard.setForeground(new Color(255, 255, 255));
		lblDashboard.setBackground(new Color(255, 255, 255));
		lblDashboard.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		lblDashboard.setBounds(22, 11, 113, 19);
		panelDashboard.add(lblDashboard);

		JPanel panelBooks = new JPanel();
		panelBooks.setBackground(new Color(0, 0, 64));
		panelBooks.setLayout(null);
		panelBooks.setBounds(0, 95, 159, 42);
		panelLeft.add(panelBooks);

		JLabel lblBooks = new JLabel("Manage Books");
		lblBooks.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ManageBooks bks = new ManageBooks();
				bks.setVisible(true);
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				panelBooks.setBackground(mouseEnterColor);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				panelBooks.setBackground(mouseExitColor);
			}
		});
		lblBooks.setForeground(new Color(192, 192, 192));
		lblBooks.setHorizontalAlignment(SwingConstants.CENTER);
		lblBooks.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblBooks.setBounds(10, 0, 139, 42);
		panelBooks.add(lblBooks);

		JPanel panelStudLst = new JPanel();
		panelStudLst.setBackground(new Color(0, 0, 64));
		panelStudLst.setLayout(null);
		panelStudLst.setBounds(0, 150, 159, 42);
		panelLeft.add(panelStudLst);

		JLabel lblStudLst = new JLabel("Student Lists");
		lblStudLst.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				StudentLists stdlst = new StudentLists();
				stdlst.setVisible(true);
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				panelStudLst.setBackground(mouseEnterColor);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				panelStudLst.setBackground(mouseExitColor);
			}
		});
		lblStudLst.setForeground(new Color(192, 192, 192));
		lblStudLst.setHorizontalAlignment(SwingConstants.CENTER);
		lblStudLst.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblStudLst.setBounds(22, 11, 113, 19);
		panelStudLst.add(lblStudLst);

		JPanel panelIssueBk = new JPanel();
		panelIssueBk.setBackground(new Color(0, 0, 64));
		panelIssueBk.setLayout(null);
		panelIssueBk.setBounds(0, 205, 159, 42);
		panelLeft.add(panelIssueBk);

		JLabel lblIssueBk = new JLabel("Issue Book");
		lblIssueBk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				IssueBook issuebook = new IssueBook();
				issuebook.setVisible(true);
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				panelIssueBk.setBackground(mouseEnterColor);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				panelIssueBk.setBackground(mouseExitColor);
			}
		});
		lblIssueBk.setForeground(new Color(192, 192, 192));
		lblIssueBk.setHorizontalAlignment(SwingConstants.CENTER);
		lblIssueBk.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblIssueBk.setBounds(22, 11, 113, 19);
		panelIssueBk.add(lblIssueBk);

		JPanel panelReturnedBk = new JPanel();
		panelReturnedBk.setBackground(new Color(0, 0, 64));
		panelReturnedBk.setLayout(null);
		panelReturnedBk.setBounds(0, 260, 159, 42);
		panelLeft.add(panelReturnedBk);

		JLabel lblReturnedBk = new JLabel("Returned Book");
		lblReturnedBk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ReturnBook returnbook = new ReturnBook();
				returnbook.setVisible(true);
				dispose();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				panelReturnedBk.setBackground(mouseEnterColor);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				panelReturnedBk.setBackground(mouseExitColor);
			}
		});
		lblReturnedBk.setForeground(new Color(192, 192, 192));
		lblReturnedBk.setHorizontalAlignment(SwingConstants.CENTER);
		lblReturnedBk.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblReturnedBk.setBounds(10, 11, 139, 19);
		panelReturnedBk.add(lblReturnedBk);

		JPanel panelViewRecords = new JPanel();
		panelViewRecords.setLayout(null);
		panelViewRecords.setBackground(new Color(0, 0, 64));
		panelViewRecords.setBounds(0, 315, 159, 42);
		panelLeft.add(panelViewRecords);

		JLabel lblViewRecords = new JLabel("View Records");
		lblViewRecords.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ViewRecords viewRec = new ViewRecords();
				viewRec.setVisible(true);
				dispose();

			}

			public void mouseEntered(MouseEvent e) {
				panelViewRecords.setBackground(mouseEnterColor);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				panelViewRecords.setBackground(mouseExitColor);
			}

		});
		lblViewRecords.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewRecords.setForeground(Color.LIGHT_GRAY);
		lblViewRecords.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblViewRecords.setBounds(10, 11, 139, 19);
		panelViewRecords.add(lblViewRecords);

		JPanel panelSignOut = new JPanel();
		panelSignOut.setLayout(null);
		panelSignOut.setBackground(new Color(0, 0, 64));
		panelSignOut.setBounds(0, 370, 159, 42);
		panelLeft.add(panelSignOut);

		JLabel lblSignOut = new JLabel("Signout");
		lblSignOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				WelcomePage singOut = new WelcomePage();
				singOut.setVisible(true);
				dispose();

			}

			public void mouseEntered(MouseEvent e) {
				panelSignOut.setBackground(mouseEnterColor);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				panelSignOut.setBackground(mouseExitColor);
			}

		});
		lblSignOut.setHorizontalAlignment(SwingConstants.CENTER);
		lblSignOut.setForeground(Color.LIGHT_GRAY);
		lblSignOut.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblSignOut.setBounds(10, 11, 139, 19);
		panelSignOut.add(lblSignOut);

		JLabel lblStudDetails = new JLabel("Student Details");
		lblStudDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblStudDetails.setForeground(new Color(32, 27, 80));
		lblStudDetails.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 14));
		lblStudDetails.setBounds(210, 99, 110, 42);
		contentPane.add(lblStudDetails);

		JPanel panelStudDetails = new JPanel();
		panelStudDetails.setBackground(new Color(248, 178, 30));
		panelStudDetails.setBounds(210, 105, 110, 35);
		contentPane.add(panelStudDetails);

		JLabel lblBkDetails = new JLabel("Book Details");
		lblBkDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblBkDetails.setForeground(new Color(32, 27, 80));
		lblBkDetails.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 14));
		lblBkDetails.setBounds(210, 280, 100, 42);
		contentPane.add(lblBkDetails);

		JPanel panelBkDetails = new JPanel();
		panelBkDetails.setBackground(new Color(248, 178, 30));
		panelBkDetails.setBounds(210, 285, 100, 35);
		contentPane.add(panelBkDetails);

		JScrollPane spStudDetails = new JScrollPane();
		spStudDetails.setBounds(210, 139, 383, 119);
		contentPane.add(spStudDetails);

		tblStudentDetails = new JTable();
		spStudDetails.setViewportView(tblStudentDetails);

		JScrollPane spBkDetails = new JScrollPane();
		spBkDetails.setBounds(210, 320, 383, 119);
		contentPane.add(spBkDetails);

		tblBookDetails = new JTable();
		tblBookDetails.setEnabled(false);
		spBkDetails.setViewportView(tblBookDetails);
		Connect();
		displayStudentDetails();
		displayBookDetails();

		JLabel lblLibMan = new JLabel("");
		lblLibMan.setIcon(new ImageIcon(HomePageAdmin.class.getResource("/Images/USTP_logo (2).png")));
		lblLibMan.setHorizontalAlignment(SwingConstants.CENTER);
		lblLibMan.setForeground(new Color(32, 27, 80));
		lblLibMan.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblLibMan.setBounds(555, 450, 60, 60);
		contentPane.add(lblLibMan);

		JLabel lblBg = new JLabel("");
		lblBg.setIcon(new ImageIcon(HomePageAdmin.class.getResource("/Images/USTP_bg (3).png")));
		lblBg.setBounds(0, 0, 614, 511);
		contentPane.add(lblBg);

	}

	public void Connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dbs_librarymanagement", "root", "");
		} catch (ClassNotFoundException | SQLException ex) {
			Logger.getLogger(HomePageAdmin.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void displayStudentDetails() {
		try {
			String query = ("SELECT * FROM tbl_studentlists");
			model = new DefaultTableModel();
			tblStudentDetails.setModel(model);

			// Clear existing data in the table model
			model.setRowCount(0);
			model.setColumnIdentifiers(new Object[] { "Student ID", "Student Name", "College", "Major Dept" });
			pst = con.prepareStatement(query);
			rs = pst.executeQuery();

			// Populate the table model with the retrieved data
			while (rs.next()) {
				model.addRow(new Object[] { rs.getString("student_id"), rs.getString("student_name"),
						rs.getString("college"), rs.getString("major_dept") });
			}

			// Set the custom model to the table

		} catch (SQLException ex) {
			ex.printStackTrace();
			Logger.getLogger(HomePageAdmin.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void displayBookDetails() {
		try {
			String query = "SELECT * FROM tbl_books";
			model = new DefaultTableModel();
			tblBookDetails.setModel(model);

			// Clear existing data in the table model
			model.setRowCount(0);
			model.setColumnIdentifiers(new Object[] { "ISBN", "Book Title", "Author", "Category" });
			pst = con.prepareStatement(query);
			rs = pst.executeQuery();

			// Populate the table model with the retrieved data
			while (rs.next()) {
				model.addRow(new Object[] { rs.getString("isbn"), rs.getString("book_title"), rs.getString("author"),
						rs.getString("category") });
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			Logger.getLogger(HomePageAdmin.class.getName()).log(Level.SEVERE, null, ex);

		}
	}
}
