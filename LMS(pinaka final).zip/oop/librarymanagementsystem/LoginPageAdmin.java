package librarymanagementsystem;

import java.sql.*;
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JToolBar;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.TextArea;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingConstants;
import javax.swing.JLayeredPane;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.SystemColor;

public class LoginPageAdmin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfUser;
	private JPasswordField tfPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPageAdmin frame = new LoginPageAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginPageAdmin() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(LoginPageAdmin.class.getResource("/Images/USTP_icon.png")));
		setTitle("Admin Login");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panelbuttonsContainer = new JPanel();
		panelbuttonsContainer.setLayout(null);
		panelbuttonsContainer.setBackground(new Color(46, 46, 46, 100));
		panelbuttonsContainer.setBounds(45, 30, 300, 300);
		contentPane.add(panelbuttonsContainer);

		JLabel lblUser = new JLabel("Username");
		lblUser.setBackground(new Color(248, 178, 30));
		lblUser.setForeground(new Color(248, 178, 30));
		lblUser.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 13));
		lblUser.setBounds(35, 90, 60, 14);
		panelbuttonsContainer.add(lblUser);

		JLabel lblPass = new JLabel("Password");
		lblPass.setBackground(new Color(248, 178, 30));
		lblPass.setForeground(new Color(248, 178, 30));
		lblPass.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 13));
		lblPass.setBounds(35, 147, 69, 14);
		panelbuttonsContainer.add(lblPass);

		tfUser = new JTextField();
		tfUser.setBounds(114, 87, 150, 20);
		panelbuttonsContainer.add(tfUser);
		tfUser.setColumns(10);

		tfPass = new JPasswordField();
		tfPass.setBounds(114, 144, 150, 20);
		panelbuttonsContainer.add(tfPass);

		JButton btnLogin = new JButton("");
		btnLogin.setIcon(new ImageIcon(LoginPageAdmin.class.getResource("/Images/Login.png")));
		btnLogin.setBounds(147, 190, 90, 25);
		panelbuttonsContainer.add(btnLogin);

		JButton btnBack = new JButton("");
		btnBack.setIcon(new ImageIcon(LoginPageAdmin.class.getResource("/Images/back (2).png")));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomePage back = new WelcomePage();
				back.setVisible(true);
				dispose();
			}
		});
		btnBack.setBounds(10, 11, 30, 25);
		panelbuttonsContainer.add(btnBack);
		
		
		JLabel lblSignUp = new JLabel("Don't have an account?");
		lblSignUp.setHorizontalAlignment(SwingConstants.CENTER);
		lblSignUp.setForeground(new Color(32, 27, 80));
		lblSignUp.setFont(new Font("Berlin Sans FB", Font.PLAIN, 10));
		lblSignUp.setBounds(35, 252, 134, 14);
		panelbuttonsContainer.add(lblSignUp);
		
		JButton btnSignUp = new JButton("");
		btnSignUp.setIcon(new ImageIcon(LoginPageAdmin.class.getResource("/Images/SignUp.png")));
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignUp signup = new SignUp();
				signup.setVisible(true);
				dispose();
			}
		});
		btnSignUp.setBounds(163, 248, 90, 25);
		panelbuttonsContainer.add(btnSignUp);
		
		

		btnLogin.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
			     String username = tfUser.getText().trim();
			        String password = tfPass.getText();

			        if (username.isEmpty() || password.isEmpty()) {
			            JOptionPane.showMessageDialog(null, "Please enter both username and password.",
			                    "Input Error", JOptionPane.WARNING_MESSAGE);
			        } else {
			            try {
			                Class.forName("com.mysql.cj.jdbc.Driver");
			                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbs_librarymanagement",
			                        "root", "");

			                String sql = "SELECT * FROM tbl_admin WHERE `username` = ? AND `create_pass` = ?";
			                PreparedStatement pstmt = con.prepareStatement(sql);
			                pstmt.setString(1, username);
			                pstmt.setString(2, password);

			                ResultSet rs = pstmt.executeQuery();

			                if (rs.next()) {
			                    JOptionPane.showMessageDialog(null, "Login Successfully...");
			                    HomePageAdmin home = new HomePageAdmin();
			                    home.setVisible(true);
			                    dispose();
			                } else {
			                    JOptionPane.showMessageDialog(null, "Incorrect Username or Password...",
			                            "Error", JOptionPane.ERROR_MESSAGE);
			                }

			                con.close();
			            } catch (Exception e) {
			                JOptionPane.showMessageDialog(null, "An error occurred while processing your request.",
			                        "Error", JOptionPane.ERROR_MESSAGE);
			            }
			        }
			    }
			});

		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
			}
		});

		JLabel lblStudLog = new JLabel("Admin Login");
		lblStudLog.setHorizontalAlignment(SwingConstants.CENTER);
		lblStudLog.setIcon(new ImageIcon(LoginPageAdmin.class.getResource("/Images/USTP_lib.png")));
		lblStudLog.setFont(new Font("Tahoma", Font.BOLD, 5));
		lblStudLog.setBounds(90, 80, 200, 200);
		contentPane.add(lblStudLog);

		JPanel panelBg = new JPanel();
		panelBg.setBounds(55, 40, 280, 280);
		panelBg.setBackground(new Color(166, 166, 166, 100));
		contentPane.add(panelBg);

		JLabel lblBg = new JLabel("");
		lblBg.setIcon(new ImageIcon(LoginPageAdmin.class.getResource("/Images/USTP_bg (6).png")));
		lblBg.setBounds(0, 0, 400, 400);
		contentPane.add(lblBg);

	}
}