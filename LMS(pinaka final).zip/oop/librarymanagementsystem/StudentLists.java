package librarymanagementsystem;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

//import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Toolkit;

public class StudentLists extends JFrame {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private DefaultTableModel model = new DefaultTableModel();

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfStudID;
	private JTextField tfStudName;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentLists frame = new StudentLists();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentLists() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(StudentLists.class.getResource("/Images/USTP_icon.png")));
		// model = new DefaultTableModel();
		setTitle("Manage Students");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 652, 437);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(248, 178, 30));
		panel.setBounds(391, 0, 245, 398);
		contentPane.add(panel);

		JLabel lblStudID = new JLabel("Enter Student ID:");
		lblStudID.setBackground(new Color(32, 27, 80));
		lblStudID.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblStudID.setForeground(new Color(32, 27, 80));
		lblStudID.setBounds(26, 30, 99, 51);
		panel.add(lblStudID);

		tfStudID = new JTextField();
		tfStudID.setColumns(10);
		tfStudID.setBounds(26, 70, 197, 25);
		panel.add(tfStudID);

		JLabel lblStudName = new JLabel("Enter Student Name:");
		lblStudName.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblStudName.setForeground(new Color(32, 27, 80));
		lblStudName.setBounds(26, 100, 144, 51);
		panel.add(lblStudName);

		tfStudName = new JTextField();
		tfStudName.setColumns(10);
		tfStudName.setBounds(26, 140, 197, 25);
		panel.add(tfStudName);

		JLabel lblCollege = new JLabel("Select College:");
		lblCollege.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblCollege.setForeground(new Color(32, 27, 80));
		lblCollege.setBounds(26, 170, 99, 51);
		panel.add(lblCollege);

		JComboBox<String> jcbCollege = new JComboBox<>();
		jcbCollege.setModel(new DefaultComboBoxModel<>(new String[] { "CITC", "CEA", "COT", "CSM", "CSTE" }));
		jcbCollege.setBounds(26, 210, 197, 25);
		panel.add(jcbCollege);

		JComboBox<String> jcbMajorDept = new JComboBox<>();
		jcbMajorDept.setModel(
				new DefaultComboBoxModel<>(new String[] { "BSIT", "BSTCM", "BSDS", "BSCS", "BSARCH", "BSENGR" }));
		jcbMajorDept.setBounds(26, 280, 197, 25);
		panel.add(jcbMajorDept);

		// buttons ///////////////////////////////////////////////

		JLabel lblDelete = new JLabel("");
		lblDelete.setIcon(new ImageIcon(StudentLists.class.getResource("/Images/delete.png")));
		lblDelete.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				deleteStudent();
			}
		});
		lblDelete.setHorizontalAlignment(SwingConstants.CENTER);
		lblDelete.setForeground(new Color(128, 0, 0));
		lblDelete.setBounds(101, 325, 41, 40);
		panel.add(lblDelete);

		JLabel lblUpdate = new JLabel("");
		lblUpdate.setIcon(new ImageIcon(StudentLists.class.getResource("/Images/update.png")));
		lblUpdate.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String stdID, stdName, cllge, major;

				stdID = tfStudID.getText();
				stdName = tfStudName.getText();
				cllge = jcbCollege.getSelectedItem().toString();
				major = jcbMajorDept.getSelectedItem().toString();

				if (isInputValid(stdID, stdName, cllge, major))
					try {
						pst = con.prepareStatement(
								" UPDATE tbl_studentlists SET student_name = ?, college = ?, major_dept = ? WHERE student_id = ?");

						pst.setString(1, stdName);
						pst.setString(2, cllge);
						pst.setString(3, major);
						pst.setString(4, stdID);

						pst.executeUpdate();
						JOptionPane.showMessageDialog(null, "Input updated successfully.");
						displayStudentLists();
						// studID.setText("");
						// studName.setText("");

						tfStudID.requestFocus();
					} catch (SQLException ex) {
						ex.printStackTrace();
						JOptionPane.showMessageDialog(null, ex.getMessage());
					}
				else {
					JOptionPane.showMessageDialog(null, "Input Required", "Error", JOptionPane.ERROR_MESSAGE);
				}

				// displaystudlsts();
			}

		});
		lblUpdate.setHorizontalAlignment(SwingConstants.CENTER);
		lblUpdate.setForeground(new Color(32, 27, 80));
		lblUpdate.setBounds(182, 325, 41, 40);
		panel.add(lblUpdate);

		JLabel lblAdd = new JLabel("");
		lblAdd.setIcon(new ImageIcon(StudentLists.class.getResource("/Images/add.png")));
		lblAdd.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String stdID, stdName, cllge, major;

				stdID = tfStudID.getText();
				stdName = tfStudName.getText();
				cllge = jcbCollege.getSelectedItem().toString();
				major = jcbMajorDept.getSelectedItem().toString();

				if (isInputValid(stdID, stdName, cllge, major))
					try {
						pst = con.prepareStatement("INSERT INTO tbl_studentlists VALUES (?, ?, ?, ?)");

						pst.setString(1, stdID);
						pst.setString(2, stdName);
						pst.setString(3, cllge);
						pst.setString(4, major);

						pst.executeUpdate();
						JOptionPane.showMessageDialog(null, "Student added successfully.");
						displayStudentLists();
						// studID.setText("");
						// studName.setText("");

						tfStudID.requestFocus();
					} catch (SQLException ex) {
						ex.printStackTrace();
						JOptionPane.showMessageDialog(null, "Invalid! Duplicate Student ID");
					}
				else {
					JOptionPane.showMessageDialog(null, "Input Required", "Error", JOptionPane.ERROR_MESSAGE);
				}

				// displaystudlsts();
			}
		});
		lblAdd.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdd.setForeground(new Color(0, 128, 64));
		lblAdd.setBounds(26, 325, 41, 40);
		panel.add(lblAdd);

		JLabel lblMajorDept = new JLabel("Select Major Department:");
		lblMajorDept.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblMajorDept.setForeground(new Color(32, 27, 80));
		lblMajorDept.setBounds(26, 240, 144, 51);
		panel.add(lblMajorDept);

		/////////////////////////////////////// end of buttons///////////////

		JScrollPane jcbScrollPane = new JScrollPane();
		jcbScrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				JTable table = (JTable) jcbScrollPane.getViewport().getView();
				int rowNo = table.getSelectedRow();
				TableModel model = table.getModel();

				tfStudID.setText(model.getValueAt(rowNo, 0).toString());
				tfStudName.setText(model.getValueAt(rowNo, 1).toString());
				jcbCollege.setSelectedItem(model.getValueAt(rowNo, 2).toString());
				jcbMajorDept.setSelectedItem(model.getValueAt(rowNo, 3).toString());

			}
		});
		jcbScrollPane.setBounds(10, 77, 371, 270);
		contentPane.add(jcbScrollPane);

		table = new JTable();
		jcbScrollPane.setViewportView(table);
		table.setEnabled(false);

		JLabel lblBack = new JLabel("");
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		lblBack.setIcon(new ImageIcon(StudentLists.class.getResource("/Images/back (2).png")));
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				HomePageAdmin homePageAdmin = new HomePageAdmin();
				homePageAdmin.setVisible(true);
				dispose();

			}
		});
		lblBack.setForeground(Color.BLACK);
		lblBack.setBounds(0, 0, 52, 52);
		contentPane.add(lblBack);
		Connect();
		displayStudentLists();
		// displaystudlsts();

		JLabel lblBg = new JLabel("");
		lblBg.setIcon(new ImageIcon(StudentLists.class.getResource("/Images/USTP_bg (4).png")));
		lblBg.setBounds(0, -48, 614, 511);
		contentPane.add(lblBg);

	}
	// last line

	// this method is to call your database
	public void Connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dbs_librarymanagement", "root", "");
		} catch (ClassNotFoundException | SQLException ex) {
			Logger.getLogger(ManageBooks.class.getName()).log(Level.SEVERE, null, ex);

		}
	}

	// last line
	// basically calling to function the table
	// Update tbl_load() method
	public void displayStudentLists() {
		try {
			pst = con.prepareStatement("SELECT * FROM tbl_studentlists");
			rs = pst.executeQuery();

			// Clear existing data in the table model
			model.setRowCount(0);
			model.setColumnIdentifiers(new Object[] { "Student ID", "Student Name", "College", "Major Dept" });

			// Populate the table model with the retrieved data
			while (rs.next()) {
				model.addRow(new Object[] { rs.getString("student_id"), rs.getString("student_name"),
						rs.getString("college"), rs.getString("major_dept") });
			}

			// Set the custom model to the table
			table.setModel(model);

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	// last line
	private void deleteStudent() {
		String stdID;
		stdID = tfStudID.getText();
		  if (!stdID.isEmpty()) {
		        try {
		            pst = con.prepareStatement("DELETE FROM tbl_studentlists WHERE student_id = ?");
		            pst.setString(1, stdID);
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Student deleted successfully.");
		            displayStudentLists();
		            // tbl_load();
		            // studID.setText("");
		            tfStudID.requestFocus();
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, ex.getMessage());
		        }
		    } else {
		        JOptionPane.showMessageDialog(null, "Input Required", "Error", JOptionPane.ERROR_MESSAGE);
		    }
		    // displaystudlsts();
		}
	
	// last line

	private boolean isInputValid(String stdID, String studName, String college, String majorDept) {
		return !stdID.isEmpty() && !studName.isEmpty() && !studName.isEmpty() && !majorDept.isEmpty();
	}
}
