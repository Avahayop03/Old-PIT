package librarymanagementsystem;

import java.sql.*;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import java.awt.Toolkit;

public class SignUp extends JFrame {
	static Connection con;
	PreparedStatement pst;
	ResultSet rs;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfFname;
	private JTextField tfCreatePassword;
	private JLabel lblUsername;
	private JTextField tfEmail;
	private JButton btnSignUp;
	private JLabel lblReturnLoginPg;
	private JButton btnLogin;
	private JLabel lblLastName;
	private JTextField tfLname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUp() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(SignUp.class.getResource("/Images/USTP_icon.png")));
		setTitle("Sign Up");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("ColorChooser.swatchesDefaultRecentColor"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblFName = new JLabel("First Name");
		lblFName.setForeground(new Color(32, 27, 80));
		lblFName.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblFName.setHorizontalAlignment(SwingConstants.CENTER);
		lblFName.setBounds(74, 142, 116, 14);
		contentPane.add(lblFName);

		tfFname = new JTextField();
		tfFname.setBounds(74, 167, 116, 20);
		contentPane.add(tfFname);
		tfFname.setColumns(10);

		JLabel lblCreatePass = new JLabel("Create Password");
		lblCreatePass.setForeground(new Color(32, 27, 80));
		lblCreatePass.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblCreatePass.setHorizontalAlignment(SwingConstants.CENTER);
		lblCreatePass.setBounds(248, 203, 116, 14);
		contentPane.add(lblCreatePass);

		lblUsername = new JLabel("Username");
		lblUsername.setForeground(new Color(32, 27, 80));
		lblUsername.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsername.setBounds(74, 204, 116, 14);
		contentPane.add(lblUsername);

		tfEmail = new JTextField();
		tfEmail.setBounds(74, 229, 116, 20);
		contentPane.add(tfEmail);
		tfEmail.setColumns(10);

		tfCreatePassword = new JTextField();
		tfCreatePassword.setBounds(248, 229, 116, 20);
		contentPane.add(tfCreatePassword);
		tfCreatePassword.setColumns(10);

		btnSignUp = new JButton("");
		btnSignUp.setIcon(new ImageIcon(SignUp.class.getResource("/Images/SignUp.png")));
		btnSignUp.addActionListener(e -> {
			String firstName = tfFname.getText();
			String lastName = tfLname.getText();
			String pass = tfCreatePassword.getText();
			String userEmail = tfEmail.getText();

			btnSignUpActionPerformed(firstName, lastName, pass, userEmail);

		});

		btnSignUp.setBounds(180, 275, 89, 23);
		contentPane.add(btnSignUp);

		lblReturnLoginPg = new JLabel("Already have an account?");
		lblReturnLoginPg.setFont(new Font("Berlin Sans FB", Font.PLAIN, 10));
		lblReturnLoginPg.setHorizontalAlignment(SwingConstants.CENTER);
		lblReturnLoginPg.setBounds(110, 349, 148, 14);
		contentPane.add(lblReturnLoginPg);

		btnLogin = new JButton("");
		btnLogin.setIcon(new ImageIcon(SignUp.class.getResource("/Images/Login.png")));
		btnLogin.setBackground(UIManager.getColor("Button.background"));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginPageAdmin login = new LoginPageAdmin();
				login.setVisible(true);
				dispose();
			}

		});
		btnLogin.setBounds(250, 345, 66, 23);
		contentPane.add(btnLogin);

		lblLastName = new JLabel("Last Name");
		lblLastName.setForeground(new Color(32, 27, 80));
		lblLastName.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblLastName.setHorizontalAlignment(SwingConstants.CENTER);
		lblLastName.setBounds(248, 142, 115, 14);
		contentPane.add(lblLastName);

		tfLname = new JTextField();
		tfLname.setColumns(10);
		tfLname.setBounds(247, 167, 116, 20);
		contentPane.add(tfLname);

		JLabel lblStudLog = new JLabel("Student Login");
		lblStudLog.setHorizontalAlignment(SwingConstants.CENTER);
		lblStudLog.setIcon(new ImageIcon(SignUp.class.getResource("/Images/USTP_lib.png")));
		lblStudLog.setFont(new Font("Tahoma", Font.BOLD, 5));
		lblStudLog.setBounds(110, -20, 200, 200);
		contentPane.add(lblStudLog);

		JPanel panelbg = new JPanel();
		panelbg.setBounds(40, 30, 350, 350);
		panelbg.setBackground(new Color(166, 166, 166, 100));
		contentPane.add(panelbg);

		JLabel lblBg = new JLabel("");
		lblBg.setIcon(new ImageIcon(SignUp.class.getResource("/Images/USTP_bg (4).png")));
		lblBg.setBounds(0, 0, 450, 450);
		contentPane.add(lblBg);
	}

	public static void Connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dbs_librarymanagement", "root", "");
		} catch (ClassNotFoundException | SQLException e) {
			Logger.getLogger(SignUp.class.getName()).log(Level.SEVERE, null, e);
		}
	}

	private void btnSignUpActionPerformed(String first_name, String last_name, String userEmail, String pass) {
		if (first_name.isEmpty() || last_name.isEmpty() || pass.isEmpty() || userEmail.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Input required");
			return;
		}
		try {
			Connect();
			String insertTblSignUpStudent = "INSERT INTO tbl_admin (`first_name`, `last_name`, `username`, `create_pass`) VALUES (?, ?, ?, ?)";
			pst = con.prepareStatement(insertTblSignUpStudent, Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, first_name);
			pst.setString(2, last_name);
			pst.setString(3, pass);
			pst.setString(4, userEmail);

			int k = pst.executeUpdate();

			if (k == 1) {
				JOptionPane.showMessageDialog(null, "Registered Successfully");
				tfFname.setText("");
				tfLname.setText("");
				tfCreatePassword.setText("");
				tfEmail.setText("");

				LoginPageAdmin loginpage = new LoginPageAdmin();
				loginpage.setVisible(true);
				dispose();
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(null, "Database Error: " + ex.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

}
