package librarymanagementsystem;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

//import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

//import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
//import net.proteanit.sql.*;
//import java.awt.Font;
//import java.awt.ScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Font;

public class ManageBooks extends JFrame {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private DefaultTableModel model;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfBkISBN;
	private JTextField tfBkTitle;
	private JTextField tfAuthorsName;
	private JTextField tfCategories;
	private JTable table;
	private JTextField tf_Search;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageBooks frame = new ManageBooks();
					Image icon = Toolkit.getDefaultToolkit().getImage("Images\\USTP_icon.png");
					frame.setIconImage(icon);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public ManageBooks() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ManageBooks.class.getResource("/Images/USTP_icon.png")));

		setTitle("Manage Books");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 656, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(248, 178, 30));
		panel.setBounds(395, 0, 245, 390);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblBkISBN = new JLabel("Enter Book ISBN:");
		lblBkISBN.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblBkISBN.setForeground(new Color(32, 27, 80));
		lblBkISBN.setBounds(26, 30, 99, 51);
		panel.add(lblBkISBN);
		
		tfBkISBN = new JTextField();
		tfBkISBN.setBounds(26, 70, 197, 25);
		panel.add(tfBkISBN);
		tfBkISBN.setColumns(10);
		
		JLabel lblBkTitle = new JLabel("Enter Book Title:");
		lblBkTitle.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblBkTitle.setForeground(new Color(32, 27, 80));
		lblBkTitle.setBounds(26, 100, 99, 51);
		panel.add(lblBkTitle);
		
		tfBkTitle = new JTextField();
		tfBkTitle.setColumns(10);
		tfBkTitle.setBounds(26, 140, 197, 25);
		panel.add(tfBkTitle);
		
		JLabel lblAuthorsName = new JLabel("Author's Name:");
		lblAuthorsName.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblAuthorsName.setForeground(new Color(32, 27, 80));
		lblAuthorsName.setBounds(26, 170, 99, 51);
		panel.add(lblAuthorsName);
		
		tfAuthorsName = new JTextField();
		tfAuthorsName.setColumns(10);
		tfAuthorsName.setBounds(26, 210, 197, 25);  
		panel.add(tfAuthorsName);
		
		JLabel lblDelete = new JLabel("");
		lblDelete.setIcon(new ImageIcon(ManageBooks.class.getResource("/Images/delete.png")));
		lblDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			deleteBook();
			}
		});
		lblDelete.setHorizontalAlignment(SwingConstants.CENTER);
		lblDelete.setForeground(new Color(245, 245, 220));
		lblDelete.setBounds(103, 325, 41, 40);
		panel.add(lblDelete);
		
		JLabel lblUpdate = new JLabel("");
		lblUpdate.setIcon(new ImageIcon(ManageBooks.class.getResource("/Images/update.png")));
		lblUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				updateBook();
			}
		
	            
			
		});
		lblUpdate.setHorizontalAlignment(SwingConstants.CENTER);
		lblUpdate.setForeground(new Color(245, 245, 220));
		lblUpdate.setBounds(182, 325, 41, 40);
		panel.add(lblUpdate);
		
		JLabel lblCategories = new JLabel("Category:");
		lblCategories.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 12));
		lblCategories.setForeground(new Color(32, 27, 80));
		lblCategories.setBounds(26, 240, 99, 51);
		panel.add(lblCategories);
		
		tfCategories = new JTextField();
		tfCategories.setColumns(10);
		tfCategories.setBounds(26, 280, 197, 25);
		panel.add(tfCategories);
		
		
		JLabel lblAdd = new JLabel("");
		lblAdd.setIcon(new ImageIcon(ManageBooks.class.getResource("/Images/add.png")));
		lblAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				addBook();
				
				
			}
		});
		lblAdd.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdd.setForeground(new Color(245, 245, 220));
		lblAdd.setBounds(26, 325, 41, 40);
		panel.add(lblAdd);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(new Color(240, 255, 240));
		panel1.setBounds(0, 0, 395, 390);
		contentPane.add(panel1);
		panel1.setLayout(null);
		
		
		JScrollPane jcbScrollPane = new JScrollPane();
		jcbScrollPane.setBounds(21, 105, 364, 249);
		panel1.add(jcbScrollPane);	
		table = new JTable();
		jcbScrollPane.setViewportView(table);
		table.setEnabled(false);
		
		
		JPanel panel2 = new JPanel();
		panel2.setBounds(21, 46, 364, 48);
		panel1.add(panel2);
		panel2.setLayout(null);
		
		tf_Search = new JTextField();  
		tf_Search.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtFieldSearch();
			}
			
			
		});
		tf_Search.setColumns(10);
		tf_Search.setBounds(126, 11, 165, 25);
		panel2.add(tf_Search);
		
		JLabel lbl_EnterBkISBN = new JLabel("Enter Book ISBN:");
		lbl_EnterBkISBN.setForeground(new Color(0, 0, 0));
		lbl_EnterBkISBN.setBounds(10, 4, 95, 39);
		panel2.add(lbl_EnterBkISBN);
		
		JLabel lbl_Refresh = new JLabel("Refresh");
		lbl_Refresh.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 btnRefresh();
			}
		});
		lbl_Refresh.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Refresh.setForeground(new Color(0, 0, 0));
		lbl_Refresh.setBounds(301, 3, 53, 40);
		panel2.add(lbl_Refresh);
		
		JLabel lblBack = new JLabel("");
		lblBack.setBounds(0, 0, 47, 40);
		panel1.add(lblBack);
		lblBack.setIcon(new ImageIcon(ManageBooks.class.getResource("/Images/back (2).png")));
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				HomePageAdmin homepageadmin = new HomePageAdmin();
				homepageadmin.setVisible(true);
				dispose();
			}
		});
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblBg = new JLabel("");
		lblBg.setHorizontalAlignment(SwingConstants.CENTER);
		lblBg.setIcon(new ImageIcon(ManageBooks.class.getResource("/Images/USTP_bg (4).png")));
		lblBg.setBounds(-102, -55, 608, 558);
		panel1.add(lblBg);
		
		model = new DefaultTableModel();
	    Connect();
	    displayBooks();
	    }
	
	
	public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/dbs_librarymanagement", "root", "");
        } catch (ClassNotFoundException | SQLException ex) {
        	 Logger.getLogger(ManageBooks.class.getName()).log(Level.SEVERE, null, ex);
            
        }
	}
	
	
	private void deleteBook() {
		String searchBTN;
		
		searchBTN = tf_Search.getText();
		if (isSearchInputValid(searchBTN))
		try {
			 pst = con.prepareStatement( "DELETE FROM tbl_books WHERE ISBN = ? ");
	       
	      
	        pst.setString(1, searchBTN);
	        pst.executeUpdate();
	        JOptionPane.showMessageDialog(null, "Book Deleted!");
	        displayBooks();
	      //  tbl_load();
	        
	        tfBkISBN.setText("");
			tfBkTitle.setText("");
			tfAuthorsName.setText("");
			tfCategories.setText("");
					
			tfBkISBN.requestFocus();
	    } catch (SQLException ex) {
	    	ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, ex.getMessage());
	    }else {
	    	JOptionPane.showMessageDialog(null, "Input Required", "Error", JOptionPane.ERROR_MESSAGE);
	    }
		//displayBooks();
	}
	private void addBook() {

		String bookISBN, book_Title, authorName, bookCategory;
		bookISBN = tfBkISBN.getText();
		book_Title = tfBkTitle.getText();
		authorName = tfAuthorsName.getText();
		bookCategory = tfCategories.getText();
		if (isInputValid(bookISBN, book_Title, authorName, bookCategory)) 
		try {
			  pst = con.prepareStatement("INSERT INTO tbl_books (ISBN, book_title, author, category, is_issued) VALUES (?, ?, ?, ?, ?)");

	            pst.setString(1, bookISBN);
	            pst.setString(2, book_Title);
	            pst.setString(3, authorName);
	            pst.setString(4, bookCategory);
	            pst.setBoolean(5, false); // Set is_issued to false initially

	        pst.executeUpdate();
	        JOptionPane.showMessageDialog(null, "Book added successfully.");
	        displayBooks();
	       // tbl_load();
	        tfBkISBN.setText("");
			tfBkTitle.setText("");
			tfAuthorsName.setText("");
			tfCategories.setText("");
			tfBkISBN.requestFocus();
	    } catch (SQLException ex) {
	    	ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Duplicate ID");
	    } else {
			JOptionPane.showMessageDialog(null, "Input Required", "Error", JOptionPane.ERROR_MESSAGE);
		}
		//displayBooks();
	}
	private void updateBook() {
		String bookISBN, book_Title, authorName, bookCategory, searchBTN;
		bookISBN = tfBkISBN.getText();
		book_Title = tfBkTitle.getText();
		authorName = tfAuthorsName.getText();
		bookCategory = tfCategories.getText();
		searchBTN = tf_Search.getText();
		if (isInputValid(bookISBN, book_Title, authorName, bookCategory)) 
		try {
			 pst = con.prepareStatement( "UPDATE tbl_books SET ISBN = ?, book_title = ?, author = ?, category = ? WHERE ISBN = ? ");
	       
	        pst.setString(1, bookISBN);
	        pst.setString(2, book_Title);
	        pst.setString(3, authorName);
	        pst.setString(4, bookCategory);
	        pst.setString(5, searchBTN);
	        pst.executeUpdate();
	        JOptionPane.showMessageDialog(null, "Book Updated!");
	        displayBooks();
	      //  tbl_load();
	        tfBkISBN.setText("");
			tfBkTitle.setText("");
			tfAuthorsName.setText("");
			tfCategories.setText("");
					
			tfBkISBN.requestFocus();
	    } catch (SQLException ex) {
	    	ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, ex.getMessage());
	    }else {
			JOptionPane.showMessageDialog(null, "Input Required", "Error", JOptionPane.ERROR_MESSAGE);
		}
		
	}
	
	private void txtFieldSearch() {
		try {
			String id = tf_Search.getText();
			 pst = con.prepareStatement("SELECT ISBN, book_title, author, category FROM tbl_books WHERE ISBN = ?");
			 pst.setString(1, id);
			 ResultSet rs = pst.executeQuery();
			 
			 if (rs.next() == true){
				 String ISBN = rs.getString(1);
				 String book_title = rs.getString(2);
				 String author = rs.getString(3);
				 String category= rs.getString(4);
				 
				 
				 
				 tfBkISBN.setText(ISBN);
				 tfBkTitle.setText(book_title);
				tfAuthorsName.setText(author);
				tfCategories.setText(category);

				tfBkISBN.requestFocus();
				 
			 } else {
				 
				 tfBkISBN.setText("");
				 tfBkTitle.setText("");
				 tfAuthorsName.setText("");
				tfCategories.setText("");
				JOptionPane.showMessageDialog(null, "Input Invalid");
				btnRefresh();
					
				 
			 }
			
			
			
		}catch (Exception exc){
			exc.printStackTrace();
		}
	}

	// Read (Display data in JTable)
	private void displayBooks() {
	    try {
	    	String query = "SELECT * FROM tbl_books";
	    	model = new DefaultTableModel();
            table.setModel(model);
	        

	        // Clear existing data in the table model
	        model.setRowCount(0);
	        model.setColumnIdentifiers(new Object[]{"ISBN", "Book Title", "Author", "Category"});
	        pst = con.prepareStatement(query);
	        rs = pst.executeQuery();

	        // Populate the table model with the retrieved data
	        while (rs.next()) {
	        	   model.addRow(new Object[]{
	        		        rs.getString("isbn"),
	        		        rs.getString("book_title"),
	        		        rs.getString("author"),
	        		        rs.getString("category")
	            });
	        }
	    } catch (SQLException ex) {
	    	ex.printStackTrace();
	    	 Logger.getLogger(ManageBooks.class.getName()).log(Level.SEVERE, null, ex);
	        
	    }
	}
	
	//a method to clear all fields


    
	private void btnRefresh() {
		tfBkISBN.setText("");
		 tfBkTitle.setText("");
		tfAuthorsName.setText("");
		tfCategories.setText("");
		tf_Search.setText("");
			
		
		
	}
	    
	private boolean isInputValid(String isbn, String title, String author, String category ) {
	    return !isbn.isEmpty() && !title.isEmpty() && !author.isEmpty() && !category.isEmpty();
	}
	private boolean isSearchInputValid(String searchBTN) {
		return !searchBTN.isEmpty();
	}

}
	
	
	
		
	  